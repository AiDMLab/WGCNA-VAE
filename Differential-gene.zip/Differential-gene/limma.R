setwd("C:\\Users\\dell\\Downloads\\geo\\txt")
logFoldChange=1
adjustP=0.05
library(limma)
rt=read.table("normalize.txt",sep='\t',header = T,check.names = F)
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimname=list(rownames(exp),colnames(exp))
rt=matrix(as.numeric(as.matrix(exp)),nrow = nrow(exp),dimnames = dimname)
#differential
modType=modType<-c(rep("normal",32),rep('tumor',0),rep("tumor",70),rep("normal",12),rep('tumor',35),rep("normal",24),rep("tumor",27),rep("normal",38))
design<-model.matrix(~0+factor(modType))
colnames(design)<-c("con","treat")
fit<-lmFit(rt,design)
cont.matrix<-makeContrasts(treat-con,levels = design)
fit2<-contrasts.fit(fit,cont.matrix)
fit2<-eBayes(fit2)
allDiff=topTable(fit2,adjust.method = 'fdr',number = 200000)
write.csv(allDiff,file="limmaTab.csv",quote=F,row.names = T)
#write table
diffSig<-allDiff[with(allDiff,(abs(logFC)>logFoldChange&adj.P.Val<adjustP)),]
write.csv(diffSig,file='diff.csv',quote = F,row.names = T)
diffUp<-allDiff[with(allDiff,(logFC>logFoldChange & adj.P.Val<adjustP)),]
write.csv(diffUp,file='up.csv',quote = F,row.names = T)
diffDown<-allDiff[with(allDiff,(logFC<(-logFoldChange) & adj.P.Val<adjustP)),]
write.csv(diffDown,file="down.csv",quote=F,row.names = T)
#volcano
pdf(file="vol.pdf")
xMax=80
yMax=max(abs(allDiff$logFC))
plot(-log10(allDiff$adj.P.Val),allDiff$logFC,xlab = "-log10(adj.P.Val)",ylab="logFC",
     main="Valcano",xlim = c(0,xMax),ylim = c(-yMax,yMax),yaxs="i",pch=20,cex=0.8)
diffSub=subset(allDiff,adj.P.Val<adjustP & logFC>logFoldChange)
points(-log10(diffSub$adj.P.Val),diffSub$logFC,pch=20,col="red",cex=0.8)
diffSub=subset(allDiff,adj.P.Val<adjustP& logFC<(-logFoldChange))
points(-log10(diffSub$adj.P.Val),diffSub$logFC,pch=20,col="green",cex=0.8)
abline(h=0,lty=2,lwd=3)
dev.off()